import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Minus, Plus, X, Search, Printer, CreditCard, FileText, Utensils } from "lucide-react";
import type { Product, Table } from "@shared/schema";

export interface OrderItemData {
  product: Product;
  quantity: number;
}

interface OrderPanelProps {
  orderItems: OrderItemData[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearOrder: () => void;
  onSaveDraft: () => void;
  onProcessPayment: (type: "kot" | "bill" | "print") => void;
  orderNumber: string;
  selectedTable: string | null;
  onSelectTable: (tableId: string) => void;
  tables: Table[];
  diningOption: string;
  onChangeDiningOption: (option: string) => void;
  searchInPacking: string;
  onSearchInPacking: (value: string) => void;
}

export function OrderPanel({
  orderItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearOrder,
  onSaveDraft,
  onProcessPayment,
  orderNumber,
  selectedTable,
  onSelectTable,
  tables,
  diningOption,
  onChangeDiningOption,
  searchInPacking,
  onSearchInPacking,
}: OrderPanelProps) {
  const subtotal = orderItems.reduce(
    (sum, item) => sum + parseFloat(item.product.price) * item.quantity,
    0
  );
  const discount = 0;
  const total = subtotal - discount;

  return (
    <div className="w-80 border-l border-border bg-card flex flex-col h-full">
      <div className="p-4 border-b border-border space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Order Summary</h2>
          {orderItems.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearOrder}
              data-testid="button-clear-order"
            >
              Clear All
            </Button>
          )}
        </div>
        
        <Select value={selectedTable || ""} onValueChange={onSelectTable}>
          <SelectTrigger data-testid="select-table">
            <SelectValue placeholder="Select Table" />
          </SelectTrigger>
          <SelectContent>
            {tables.map((table) => (
              <SelectItem key={table.id} value={table.id}>
                Table {table.tableNumber}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-3">
          {orderItems.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <p className="text-sm">No items in order</p>
              <p className="text-xs mt-1">Add products to get started</p>
            </div>
          ) : (
            orderItems.map((item) => (
              <Card key={item.product.id} className="p-3" data-testid={`card-order-item-${item.product.id}`}>
                <div className="flex gap-3">
                  <div className="w-16 h-16 rounded-md bg-muted overflow-hidden flex-shrink-0">
                    {item.product.imageUrl ? (
                      <img
                        src={item.product.imageUrl}
                        alt={item.product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-muted to-accent">
                        <Utensils className="w-6 h-6 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h4 className="font-medium text-sm truncate">
                        {item.product.name}
                      </h4>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 flex-shrink-0"
                        onClick={() => onRemoveItem(item.product.id)}
                        data-testid={`button-remove-item-${item.product.id}`}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                          data-testid={`button-decrease-${item.product.id}`}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-8 text-center font-medium font-mono" data-testid={`text-quantity-${item.product.id}`}>
                          {item.quantity}
                        </span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                          data-testid={`button-increase-${item.product.id}`}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                      
                      <span className="font-semibold text-sm font-mono" data-testid={`text-item-total-${item.product.id}`}>
                        ${(parseFloat(item.product.price) * item.quantity).toFixed(2)}
                      </span>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-auto p-0 text-xs text-muted-foreground mt-1"
                      data-testid={`button-add-notes-${item.product.id}`}
                    >
                      + Add Notes
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-border space-y-4">
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Sub total :</span>
            <span className="font-mono" data-testid="text-subtotal">${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Product Discount :</span>
            <span className="font-mono" data-testid="text-discount">${discount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Extra Discount :</span>
            <span className="font-mono">$0.00</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Coupon discount :</span>
            <span className="font-mono">$0.00</span>
          </div>
          <div className="h-px bg-border my-2" />
          <div className="flex justify-between font-semibold text-base">
            <span>Total :</span>
            <span className="font-mono" data-testid="text-total">${total.toFixed(2)}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={() => onProcessPayment("kot")}
            disabled={orderItems.length === 0}
            className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
            data-testid="button-receipt-print"
          >
            <Printer className="w-4 h-4" />
            Receipt Print
          </Button>
          <Button
            variant="outline"
            onClick={onSaveDraft}
            disabled={orderItems.length === 0}
            className="gap-2 bg-sky-500 hover:bg-sky-600 text-white border-sky-500"
            data-testid="button-draft"
          >
            Draft
          </Button>
        </div>
        
        <Button
          variant="secondary"
          onClick={() => onProcessPayment("print")}
          disabled={orderItems.length === 0}
          className="w-full gap-2"
          data-testid="button-complete-order"
        >
          <FileText className="w-4 h-4" />
          Complete Order
        </Button>
      </div>
    </div>
  );
}
